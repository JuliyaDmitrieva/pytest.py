# pytest.py
Автотеcты на API на Pytest Requests Python
